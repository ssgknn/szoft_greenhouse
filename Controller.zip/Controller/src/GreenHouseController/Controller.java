/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package GreenHouseController;

/**
 *
 * @author nagyn_f8j2p5
 */



import java.io.IOException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.HashMap;




public class Controller {
    
    
    HashMap<Double, Double> temperatureHumidity = new HashMap<Double, Double>();

    //Hash const data
      {
        temperatureHumidity.put(Double.valueOf(20), 17.3);
        temperatureHumidity.put(Double.valueOf(21), 18.5);
        temperatureHumidity.put(Double.valueOf(22), 19.7);
        temperatureHumidity.put(Double.valueOf(23), 20.9);
        temperatureHumidity.put(Double.valueOf(24), 22.1);
        temperatureHumidity.put(Double.valueOf(25), 23.3);
        temperatureHumidity.put(Double.valueOf(26), 24.7);
        temperatureHumidity.put(Double.valueOf(27), 26.1);
        temperatureHumidity.put(Double.valueOf(28), 27.5);
        temperatureHumidity.put(Double.valueOf(29), 28.9);
        temperatureHumidity.put(Double.valueOf(30), 30.3);
        temperatureHumidity.put(Double.valueOf(31), 31.9);
        temperatureHumidity.put(Double.valueOf(32), 33.5);
        temperatureHumidity.put(Double.valueOf(33), 35.1);
        temperatureHumidity.put(Double.valueOf(34), 36.7);
        temperatureHumidity.put(Double.valueOf(35), 38.3);
        }
    
    
    
    String boiler(double actualTemp, double actualHumidity, double minTemp, double minHumidity,
                  double optimalTemp, boolean isBoilerActive, boolean isSprinklerOn){
        
        
        if ((optimalTemp - actualTemp) >= 5) {
            FileWriter fileHandler = null;
            
            try {
                fileHandler = new FileWriter("error_log.txt", true);
                BufferedWriter buffered = new BufferedWriter(fileHandler);
                buffered.write(String.valueOf(LocalDateTime.now()) + " " +
                                        String.valueOf(LocalTime.now()) +
                                        "Temperature failure (defective data) : " +
                                        String.valueOf((optimalTemp - actualTemp)));
                buffered.newLine();
                buffered.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        
        
        if ((minHumidity - actualHumidity) >= 20) {
            FileWriter fileHandler = null;
            try {
                fileHandler = new FileWriter("error_log.txt", true);
                BufferedWriter buffered = new BufferedWriter(fileHandler);
                buffered.write(String.valueOf(LocalDateTime.now()) +
                                        " " + String.valueOf(LocalTime.now()) +
                                        "Humidity failure (defective data): " +
                                        String.valueOf((minHumidity - actualHumidity)));
                buffered.newLine();
                buffered.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        
        
        System.out.println(actualTemp + "act?" + minTemp +"min:" + optimalTemp + "opt," + actualHumidity + "act?" + minHumidity+"min");
        if (actualTemp >= minTemp) {
            return "bup" + String.valueOf(0) + "c";
        } else {
            return "bup" + String.valueOf((int) (optimalTemp - actualTemp)) + "c";
        }
    }

    String sprinkler(double greenhouse_size, double actualTemperature, double actualHumidity, double minHumidity, double optimalTemperature, double minTemperature) {
        double water = 0;
        double waterToAdd = 0;
        double differencial;
        double humidityDif;
        double waterDif = 0;
        if (actualTemperature < minTemperature)
        {
            for (Double i : temperatureHumidity.keySet()) {
                if (i == actualTemperature) {
                    water = temperatureHumidity.get(i);
                    water *= (actualHumidity / 100);
                    System.out.println("act_water:"+water);
                    break;
                }
            }
            for (Double i : temperatureHumidity.keySet()) {
                if (i == optimalTemperature) {
                    waterToAdd = temperatureHumidity.get(i);
                    System.out.println("needed_water:"+waterToAdd);
                    break;
                }
            }
            humidityDif = water / waterToAdd;
            System.out.println("fut_hum"+humidityDif);
            if( (humidityDif*100) < minHumidity)
            {
                waterDif = ( ( ( ( (waterToAdd*(minHumidity/100)/*18,18*/ )-water/*1,87*/) /0.01/*187*/) )*greenhouse_size/*224400*/)/1000;//224,4
            }
            return "son" + String.valueOf((int)waterDif) + "l";
        } else {
            if (actualHumidity >= minHumidity)
            {
                return "son" + String.valueOf(0) + "l";
            }
            else {
                for (Double i : temperatureHumidity.keySet()) {
                    if (i == actualTemperature) {
                        waterToAdd = temperatureHumidity.get(i);
                        waterToAdd *= (minHumidity / 100);
                        break;
                    }
                }
                for (Double i : temperatureHumidity.keySet()) {
                    if (i == actualTemperature) {
                        water = temperatureHumidity.get(i);
                        water *= (actualHumidity / 100);
                        break;
                    }
                }
                differencial = (((waterToAdd - water) / 0.01) * greenhouse_size) / 1000;
                return "son" + String.valueOf((int) differencial) + "l";
            }
        }
    }
}

