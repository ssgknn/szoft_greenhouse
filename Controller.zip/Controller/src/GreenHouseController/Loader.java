/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package GreenHouseController;

/**
 *
 * @author nagyn_f8j2p5
 */



import java.io.IOException;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;


public class Loader implements  ILoader{
    

    @Override
    public GreenHouseList loadGreenHouses() throws IOException {
        
        JSONObject JSON = JSONOperation.readJsonFromUrl("http://193.6.19.58:8181/greenhouse");
        JSONArray ja = JSON.getJSONArray("greenhouseList");
        ArrayList<Greenhouse> toParse = new ArrayList<Greenhouse>();
        GreenHouseList toReturn = new GreenHouseList();

        for (int i = 0; i < ja.length(); i++) {
            JSONObject jsonobject = ja.getJSONObject(i);

            String ghId = jsonobject.getString("ghId");
            String description = jsonobject.getString("description");
            int temperature_min = jsonobject.getInt("temperature_min");
            int temperature_opt = jsonobject.getInt("temperature_opt");
            int humidity_min = jsonobject.getInt("humidity_min");
            int volume = jsonobject.getInt("volume");

            System.out.println(ghId + " " + description + " "  +
                               temperature_min + " "  +
                               temperature_opt + " "  +
                               humidity_min + " "  +
                               volume);
            
            Greenhouse current = new Greenhouse(ghId,description,temperature_min,temperature_opt,humidity_min,volume);
            toParse.add(current);
        }
        toReturn.setGreenhouses(toParse);
        return toReturn;
    }
}
