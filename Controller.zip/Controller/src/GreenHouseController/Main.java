/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package GreenHouseController;

/**
 *
 * @author nagyn_f8j2p5
 */



import org.json.JSONException;
import java.io.IOException;
import static java.lang.String.valueOf;



public class Main {
    public static void main(String[] args) throws IOException, JSONException {
        
    ILoader.GreenHouseList greenhouses = new Loader().loadGreenHouses();
    
    System.out.println("\n");
    
    for (ILoader.Greenhouse i : greenhouses.getGreenhouses()) {
        IMonitor.SensorData currentSensorData = new Monitor().getSensorData(i.getGhId());
        int errorMsg = new Driver().sendCommand(i, currentSensorData.getToken(),
                                                currentSensorData.getTemperature_act(),
                                                currentSensorData.getHumidity_act());
        System.out.println(valueOf(errorMsg)+ "\n");
        }
    }
}