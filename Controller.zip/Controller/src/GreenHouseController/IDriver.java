/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package GreenHouseController;

/**
 *
 * @author nagyn_f8j2p5
 */



import java.io.IOException;


public interface IDriver {
    public int sendCommand(ILoader.Greenhouse gh, String token,
                            double boilerValue, double sprinklerValue) throws IOException;
    
    class Command
    {
        public String ghId;
        public String boilerCommand;
        public String sprinklerCommand;
    }
  
}
