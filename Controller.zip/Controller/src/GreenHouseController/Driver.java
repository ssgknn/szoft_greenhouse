/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package GreenHouseController;

/**
 *
 * @author nagyn_f8j2p5
 */



import java.io.*;
import static java.lang.Integer.parseInt;
import java.net.*;



public class Driver implements  IDriver {
    
    public int sendCommand(ILoader.Greenhouse gh, String token, double boilerValue, double sprinklerValue) throws IOException {

        URL url;
        url = new URL("http://193.6.19.58:8181/greenhouse/" + token);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        {
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "text/plain");
                connection.setRequestProperty("charset", "utf-8");
                connection.setDoOutput(true);
        }
        IMonitor.SensorData currentSensorData = new Monitor().getSensorData(gh.getGhId());
        Controller currentCommand = new Controller();
        String boilerToDo = "";
        String sprinklerToDo = "";
        if(!currentSensorData.isBoiler_on() && !currentSensorData.isSprinkler_on()) {
            boilerToDo = currentCommand.boiler(currentSensorData.getTemperature_act(), currentSensorData.getHumidity_act(), gh.getTemperature_min(), gh.getHumidity_min(), gh.getTemperature_opt(), currentSensorData.isBoiler_on(), currentSensorData.isSprinkler_on());
            sprinklerToDo = currentCommand.sprinkler(Double.valueOf(gh.getVolume()), currentSensorData.getTemperature_act(), currentSensorData.getHumidity_act(), gh.getHumidity_min(), gh.getTemperature_opt(), gh.getTemperature_min());
        }
        System.out.println(boilerToDo);
        System.out.println(sprinklerToDo);
        String jsonInputString = "{\"ghId\":\""+gh.getGhId()+"\",\"boilerCommand\":\""+boilerToDo+"\",\"sprinklerCommand\":\""+sprinklerToDo+"\"}";
        System.out.println(jsonInputString);

        try(OutputStream outputStream = connection.getOutputStream()) {
            byte[] input = jsonInputString.getBytes("utf-8");
            outputStream.write(input, 0, input.length);
        }

        try(BufferedReader br = new BufferedReader(
                new InputStreamReader(connection.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            return parseInt(response.toString());
        }
    }
}